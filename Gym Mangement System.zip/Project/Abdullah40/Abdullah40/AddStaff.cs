﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class AddStaff : Form
    {
        public AddStaff()
        {
            InitializeComponent();
        }

        private void AddStaff_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string SName = txtSName.Text;
            string Sid = txtSid.Text;
            string SM = txtSEmail.Text;
            string Sc = txtScn.Text;
            string Scnic = txtSCnic.Text;
            DateTime Sdob = dateofbirths.Value;
            DateTime Sdoj = dateofjoins.Value;
            string Spn = txtPn.Text;
            string SCity = txtCity.Text;
            string Sgender = radioMale.Checked ? radioMale.Text : radioFemale.Text;

            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

            string insertQuery = @"
INSERT INTO AddStaff (Name, Sid, Email, ContactNumber, CNIC, DateOfBirth, DateOfJoining, PhoneNumber, City, Gender)
VALUES (@Name, @Sid, @Email, @ContactNumber, @CNIC, @DateOfBirth, @DateOfJoining, @PhoneNumber, @City, @Gender)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(insertQuery, connection);
                command.Parameters.AddWithValue("@Name", SName);
                command.Parameters.AddWithValue("@Sid", Sid);
                command.Parameters.AddWithValue("@Email", SM);
                command.Parameters.AddWithValue("@ContactNumber", Sc);
                command.Parameters.AddWithValue("@CNIC", Scnic);
                command.Parameters.AddWithValue("@DateOfBirth", Sdob);
                command.Parameters.AddWithValue("@DateOfjoining", Sdoj);
                command.Parameters.AddWithValue("@PhoneNumber", Spn);
                command.Parameters.AddWithValue("@City", SCity);
                command.Parameters.AddWithValue("@Gender", Sgender);

                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Data inserted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert data.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

     

        private void button1_Click(object sender, EventArgs e)
        {
            txtSName.Text = string.Empty;
            txtSid.Text = string.Empty;
            txtSEmail.Text = string.Empty;
            txtScn.Text = string.Empty;
            txtSCnic.Text = string.Empty;
            dateofbirths.Value = DateTime.Today;
            dateofjoins.Value = DateTime.Today;
            txtPn.Text = string.Empty;
            txtCity.Text = string.Empty;
            radioMale.Checked = false;
            radioFemale.Checked = false;
        }
    }
}
