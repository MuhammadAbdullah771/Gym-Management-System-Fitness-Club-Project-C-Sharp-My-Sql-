﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            AddMember newForm = new AddMember();
            newForm.Show();
        }

        private void addMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddMember newForm = new AddMember();
            newForm.Show();
        }

        private void addStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStaff newForm = new AddStaff();
            newForm.Show();

        }

        private void equipmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Equipments es = new Equipments();
            es.Show();
        }

        private void serachMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchMember sm = new SearchMember();
            sm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5  F5 =new Form5();
            F5.Show();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Log OUT !! Confirm?", "LOG OUT ", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)  
            {
                this.Close();
                login lg = new login();
            }
        }

        private void deleteMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DelMember dl = new DelMember();
            dl.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void exitToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            // Show a confirmation dialog before exiting the application
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Application",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
                       
        

