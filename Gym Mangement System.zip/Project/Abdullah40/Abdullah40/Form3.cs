﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";
            string query = "SELECT * FROM Equipments"; 
            using (SqlConnection connection = new SqlConnection(connectionString)) 
            { try { connection.Open(); SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table; }
                catch (Exception ex)
                { MessageBox.Show("An error occurred: " + ex.Message); 
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }
    }
}
