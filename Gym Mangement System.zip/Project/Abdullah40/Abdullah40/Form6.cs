﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            {
                // Connection string
                string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

                // SQL query to fetch payment data
                string fetchQuery = "SELECT PaymentId, MId, MemberName, Amount, PaymentStatus, PaymentDate FROM Payments";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Open the connection
                        con.Open();

                        // Create the data adapter and fill the dataset
                        using (SqlDataAdapter adapter = new SqlDataAdapter(fetchQuery, con))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind the data to the DataGridView
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                    catch (Exception ex)
                    {
                        // Display error message
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string searchValue = txtId.Text;
            SearchData(searchValue);
        }

        private void SearchData(string searchValue)
        {
            // Connection string
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

            // SQL query to fetch payment data based on Member ID or Name
            string fetchQuery = @"
                SELECT PaymentId, MId, MemberName, Amount, PaymentStatus, PaymentDate 
                FROM Payments 
                WHERE MId LIKE '%' + @SearchValue + '%' OR MemberName LIKE '%' + @SearchValue + '%'";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    con.Open();

                    // Create the command and add parameters
                    using (SqlCommand cmd = new SqlCommand(fetchQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@SearchValue", searchValue);

                        // Create the data adapter and fill the dataset
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind the data to the DataGridView
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
