﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class AddMember : Form
    {
        public AddMember()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string MName = txtFMembername.Text;
            string MId = txtMemberId.Text;
            string Mail = txtEmail.Text;
            string CNumber = txtContactNumber.Text;
            string MAddress = txtAddress.Text;
            string Cnic = txtCnicNumber.Text;
            string MsType = radioButton1.Checked ? radioButton1.Text : radioButton3.Text;
            string gender = radioMale.Checked ? radioMale.Text : radioFemale.Text;
            DateTime dob = dateOfBirth.Value;
            DateTime doj = dateOfJoin.Value;


            if (string.IsNullOrWhiteSpace(MName) || string.IsNullOrWhiteSpace(MId))
            {
                MessageBox.Show("Member ID and Member Name are required.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

            // SQL query for inserting data
            string insertQuery = @"
                INSERT INTO AddMembers (MName, Mail, CNumber, MsType, doj, dob, MAddress, Cnic, gender)
                VALUES (@MName, @Mail, @CNumber, @MsType, @doj, @dob, @MAddress, @Cnic, @gender)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    con.Open();

                    // Create the command and add parameters
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@MName", MName);
                        cmd.Parameters.AddWithValue("@Mail", Mail);
                        cmd.Parameters.AddWithValue("@CNumber", CNumber);
                        cmd.Parameters.AddWithValue("@MsType", MsType);
                        cmd.Parameters.AddWithValue("@doj", doj);
                        cmd.Parameters.AddWithValue("@dob", dob);
                        cmd.Parameters.AddWithValue("@MAddress", MAddress);
                        cmd.Parameters.AddWithValue("@Cnic", Cnic);
                        cmd.Parameters.AddWithValue("@gender", gender);

                        // Execute the query
                        cmd.ExecuteNonQuery();

                        // Display success message
                        MessageBox.Show("Data saved successfully!");
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    MessageBox.Show("Error: " + ex.Message);
                }
            }

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
                    }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtFMembername_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMemberId_TextChanged(object sender, EventArgs e)
        {

        }

        private void RestButton_Click(object sender, EventArgs e)
        {
            txtFMembername.Clear();
            txtMemberId.Clear();    
            txtEmail.Clear();   
            txtContactNumber.Clear();
            txtAddress.Clear();
            txtCnicNumber.Clear();
            txtMemberId.Clear() ;
            radioFemale.Checked = false;
            radioMale.Checked = false;
            dateOfBirth.Value = DateTime.Now;
            dateOfJoin.Value = DateTime.Now;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
