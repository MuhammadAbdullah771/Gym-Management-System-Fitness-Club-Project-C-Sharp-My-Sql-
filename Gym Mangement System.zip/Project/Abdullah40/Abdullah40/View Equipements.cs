﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class View_Equipments : Form
    {
        public View_Equipments()
        {
            InitializeComponent();
        }

        private void View_Equipments_Load(object sender, EventArgs e)
        {

        }
    }
}
