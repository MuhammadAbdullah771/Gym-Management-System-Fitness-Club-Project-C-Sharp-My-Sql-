﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtPaymentId.Clear();
            txtAmount.Clear();
            txtStatus.Clear();
            txtMemberId.Clear();
            dateTimePicker1.Value = DateTime.Today; ;
            txtMemberName.Clear();  
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string PaymentId = txtPaymentId.Text;
            string MemberId= txtMemberId.Text;
            string MemberName = txtMemberName.Text;
            string Amount = txtAmount.Text; 
            string PaymentStatus = txtStatus.Text;
            DateTime PaymentDate = dateTimePicker1.Value;

            if (string.IsNullOrWhiteSpace(MemberId) || string.IsNullOrWhiteSpace(MemberName))
            { MessageBox.Show("Member ID and Member Name are required."); return; }
            // Connection string 
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";
            // SQL query for inserting data 
            string insertQuery = @" INSERT INTO Payments (MId, MemberName, Amount, PaymentStatus, PaymentDate) VALUES (@MId, @MemberName, @Amount, @PaymentStatus, @PaymentDate)";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                { // Open the connection 
                    con.Open();
                    // Create the command and add parameters 
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@MId", MemberId); cmd.Parameters.AddWithValue("@MemberName", MemberName); cmd.Parameters.AddWithValue("@Amount", Amount);
                        cmd.Parameters.AddWithValue("@PaymentStatus", PaymentStatus);
                        cmd.Parameters.AddWithValue("@PaymentDate", PaymentDate);
                        // Execute the query
                        cmd.ExecuteNonQuery();
                        // Display success message 
                        MessageBox.Show("Payment data saved successfully!");
                    }
                }
                catch (Exception ex)
                { // Display error message 
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
}

        private void Form5_Load(object sender, EventArgs e)
        {
            {
                // Connection string
                string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

                // SQL query to fetch payment data
                string fetchQuery = "SELECT PaymentId, MId, MemberName, Amount, PaymentStatus, PaymentDate FROM Payments";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Open the connection
                        con.Open();

                        // Create the data adapter and fill the dataset
                        using (SqlDataAdapter adapter = new SqlDataAdapter(fetchQuery, con))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind the data to the DataGridView
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                    catch (Exception ex)
                    {
                        // Display error message
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Retrieve values from form controls
            string PaymentId = txtPaymentId.Text;
            string MemberId = txtMemberId.Text;
            string MemberName = txtMemberName.Text;
            string Amount = txtAmount.Text;
            string PaymentStatus = txtStatus.Text;
            DateTime PaymentDate = dateTimePicker1.Value;

            // Validate inputs
            if (string.IsNullOrWhiteSpace(PaymentId))
            {
                MessageBox.Show("Payment ID is required for updating.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

            // SQL query for updating data
            string updateQuery = @"
                UPDATE Payments
                SET MId = @MId, 
                    MemberName = @MemberName, 
                    Amount = @Amount, 
                    PaymentStatus = @PaymentStatus, 
                    PaymentDate = @PaymentDate
                WHERE PaymentId = @PaymentId";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    con.Open();

                    // Create the command and add parameters
                    using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@PaymentId", PaymentId);
                        cmd.Parameters.AddWithValue("@MId", MemberId);
                        cmd.Parameters.AddWithValue("@MemberName", MemberName);
                        cmd.Parameters.AddWithValue("@Amount", Amount);
                        cmd.Parameters.AddWithValue("@PaymentStatus", PaymentStatus);
                        cmd.Parameters.AddWithValue("@PaymentDate", PaymentDate);

                        // Execute the update query
                        cmd.ExecuteNonQuery();

                        // Display success message
                        MessageBox.Show("Payment data updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        
}

        private void button5_Click(object sender, EventArgs e)
        {
            // Retrieve values from form controls 
            string PaymentId = txtPaymentId.Text;
            // Validate inputs 
            if (string.IsNullOrWhiteSpace(PaymentId))
            { MessageBox.Show("Payment ID is required for deleting."); return; }
            // Connection string 
            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";
            // SQL query for deleting data 
            string deleteQuery = @" DELETE FROM Payments WHERE PaymentId = @PaymentId";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                { // Open the connection
                  con.Open(); 
                  // Create the command and add parameters
                    using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@PaymentId", PaymentId);
                        // Execute the delete query 
                        cmd.ExecuteNonQuery();
                        // Display success message
                        MessageBox.Show("Payment data deleted successfully!");
                    }
                }
                catch (Exception ex)
                {
                    // Display error message
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

