﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class SearchMember : Form
    {
        public SearchMember()
        {
            InitializeComponent();
        }

        private void SearchMember_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = DESKTOP-2S07L9S; database = MrAbdullahFitnessClub; Integrated security=True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "select * From AddMembers";

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;"))
            {
                try
                {
                    con.Open();

                    if (!string.IsNullOrWhiteSpace(txtSm.Text))
                    {
                        using (SqlCommand cmd = new SqlCommand("SELECT * FROM AddMembers WHERE MId = @MId", con))
                        {
                            cmd.Parameters.AddWithValue("@MId", txtSm.Text);

                            SqlDataAdapter ad = new SqlDataAdapter(cmd);
                            DataSet DS = new DataSet();
                            ad.Fill(DS);

                            if (DS.Tables[0].Rows.Count > 0)
                            {
                                dataGridView1.DataSource = DS.Tables[0];
                            }
                            else
                            {
                                MessageBox.Show("No records found.");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid Member ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
