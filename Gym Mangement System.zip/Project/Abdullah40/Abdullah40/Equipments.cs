﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abdullah40
{
    public partial class Equipments : Form
    {
        public Equipments()
        {
            InitializeComponent();
        }

        private void Equipments_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string EName = txtEName.Text;
            string Description = txtDescription.Text;
            string MusclesName = txtMuscles.Text; // Corrected here to use the appropriate textbox for MusclesName
            DateTime dateTime = DeliveryTime.Value;
            string Cost = txtCost.Text;

            string connectionString = "Data Source=DESKTOP-2S07L9S;Initial Catalog=MrAbdullahFitnessClub;Integrated Security=True;";

            string insertQuery = @"
    INSERT INTO Equipments (EquipmentsName, Description, MusclesName, DeliveryTime, Cost)
    VALUES (@EquipmentsName, @Description, @MusclesName, @DeliveryTime, @Cost)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(insertQuery, connection);
                command.Parameters.AddWithValue("@EquipmentsName", EName);
                command.Parameters.AddWithValue("@Description", Description);
                command.Parameters.AddWithValue("@MusclesName", MusclesName);
                command.Parameters.AddWithValue("@DeliveryTime", dateTime);
                command.Parameters.AddWithValue("@Cost", Cost);

                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Data inserted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert exercise data.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtEName.Text = string.Empty;
            txtDescription.Text = string.Empty; 
            txtMuscles.Text = string.Empty;
            DeliveryTime.Value = DateTime.Today;
            txtCost.Text = string.Empty;
        }

        private void button3_Click(object sender, EventArgs e)
        { Form3 VE = new Form3();
            VE.Show();
        } 
      
    }

    }
